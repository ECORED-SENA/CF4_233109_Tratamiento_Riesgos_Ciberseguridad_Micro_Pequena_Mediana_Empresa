function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6OMR9yutkiC":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

